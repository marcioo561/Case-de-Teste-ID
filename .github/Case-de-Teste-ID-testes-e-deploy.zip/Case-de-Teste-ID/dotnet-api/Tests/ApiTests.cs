using Xunit;

namespace dotnet_api.Tests
{
    public class ApiTests
    {
        [Fact]
        public void Test1_Ping()
        {
            Assert.True(true);
        }
    }
}
